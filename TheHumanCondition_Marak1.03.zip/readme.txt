 The Inhuman Condition Overhaul Mod

This mod was created to drive us out of our base, use new skills and create a more dangerous environment.  Along the way many more changes have been added.

Before I get into the details I would like to thank the following

Guppy's Unofficial 7DtD Modding Server on Discord:  Without this channel to help me track down bugs, give me ideas and help me keep my sanity over the last 6+ months, this would never have been finished.
Yatch: Co-creator of this mod, a little mentally unhinged, and as much of a sucker for punishment as myself.
Khaine20: Provided some amazing mods for the community, which helped shape this overhaul greatly.
JaxTeller718: His zombieReach modlet is a great quality of life for servers with high ping for some players.
OCB: His stop fuel waste was probably *the* most requested feature I had from a certain subsect of players.


T.I.C Details

Noclass:  Written by myself, this modlet changes all perks to be modifier based.  As you loot and explore the world you will find armor mod's that give a 1 point bonus to a particular perk(and 2 points into the corresponding statistic so that you can use the perk).  This is the only way to unlock perks(Aside from 4 points given after the initial quest, to help you get started).  Every perk has a corresponding mod, and to account for the high number of mods required per player, all armor has had its slot count increased.

Expanded Cooking:  Written by myself, this modlet allows master chefs (5th rank perk in master chef) to create a new workbench called an Advanced Cooking Station.  This station allows substitution of ingredients, simplifying farming and food cooking.  Similar to a forge, raw ingredients must been processed in, and the recipe must be known to be able to cook it out.

 
Way of the Blade: Written by myself, this modlet adds a new book series for bladed weapons, including a new bladed weapon mod.  Also unlocks a Katana(crafted using machete parts and some other ingredients).  A high swing speed weapon with moderate damage(Tier 3).

 
Log Spikes:  They're back due to high request, 3 levels - perfect for that echidna style base.

Quality of life changes:  Glue with fresh water, cloth crafted arrows(in addition to feathers), Lootbag slight increase drop rate, Heatmap changes(higher - much higher).

New workbenches:  Advanced Cooking Station(see expanded cooking) and Advanced Mod Workbench (combine diamonds and full stack of perk mods to create a master mod).


Khaine20's mods included:  3 Slot forge, 12 Craft Queue, 15 slot toolbelt, 60 slot backpack, Dangerous Cities(heavily modified), Wandering Horde Patch(heavily modified) and Lockable Inventory Slots.
Note
Dangerous Cities: I have modified this so that the (greatly increased) number of zombies come in waves, to reduce the massive amount of overhead we were getting with full spawns.
Wandering Horde:  Slower buildup than Khaine initially designed.

JaxTeller718's mod included: Zombie reach (helps a lot with players connecting with a moderate to high ping) Waiting on Author to respond modlet removed temporarily - I recommend you grab it as well

OCB's mod included: Stop Fuel Waste, all fuel using workbench's automatically shut off when finished processing queues(input AND output).

 
This mod has been written with a storyline in mind, which is currently being worked on.  Popular opinion from the testers has convinced me to release early, and get feedback on core systems while continuing the work on the storyline.
The most frequent comment I have received from testers is the new skills they are being forced to use, as they do not have a choice of perks to equip until they find them.

Recommended settings:  Any map, 300% exp(this is an additional difficulty slider, as you wont be gaining perks), 90 minute day.  As always, the choice is yours, this is what the primary testing was done on.

Feedback is best on the 7 days to die forum thread, or if you are a modder, I hope to get a sub-channel on Guppy's unofficial 7DtD server to talk to people on.

Thank you all, happy hunting and good luck.

 - Marak 